import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Heart, 
  Globe, 
  Users, 
  Calendar,
  MapPin,
  CheckCircle,
  ArrowRight,
  Stethoscope,
  Award,
  Clock,
  BookOpen
} from 'lucide-react';

// Import images
import heroImage from '@/assets/hero-medical.jpg';
import educationBg from '@/assets/education-bg.jpg';

const Volunteering = () => {
  const programs = [
    {
      title: "Global Health Missions",
      location: "Various International Locations",
      duration: "2-4 weeks",
      commitment: "Full-time",
      description: "Provide medical care in underserved communities worldwide while gaining invaluable clinical experience.",
      requirements: ["Medical degree or advanced student status", "Current medical license", "Vaccination requirements"],
      nextMission: "March 15, 2024",
      featured: true
    },
    {
      title: "Community Health Outreach",
      location: "Local Communities",
      duration: "Ongoing",
      commitment: "Flexible (weekends)",
      description: "Support local health screenings, vaccination drives, and health education programs in our community.",
      requirements: ["Medical training (any level)", "Background check", "Orientation completion"],
      nextMission: "Every Saturday"
    },
    {
      title: "Medical Education Support",
      location: "Dr. Edumed Academy",
      duration: "Academic year",
      commitment: "Part-time",
      description: "Mentor medical students, assist with clinical training, and support educational initiatives.",
      requirements: ["Professional medical experience", "Teaching interest", "Time commitment availability"],
      nextMission: "February 1, 2024"
    },
    {
      title: "Emergency Response Team",
      location: "Regional Coverage",
      duration: "On-call basis",
      commitment: "Emergency response",
      description: "Join our rapid response team for natural disasters and emergency medical situations.",
      requirements: ["Emergency medicine training", "Rapid deployment availability", "Crisis management skills"],
      nextMission: "As needed"
    }
  ];

  const benefits = [
    {
      icon: Heart,
      title: "Make a Real Impact",
      description: "Directly improve health outcomes in underserved communities while gaining meaningful experience."
    },
    {
      icon: Globe,
      title: "Global Experience",
      description: "Work in diverse cultural settings and expand your understanding of global health challenges."
    },
    {
      icon: Users,
      title: "Professional Network",
      description: "Connect with like-minded healthcare professionals and build lasting professional relationships."
    },
    {
      icon: Award,
      title: "Career Enhancement",
      description: "Strengthen your resume with volunteer experience that demonstrates your commitment to service."
    }
  ];

  const testimonials = [
    {
      name: "Dr. Sarah Martinez",
      role: "Emergency Medicine Physician",
      program: "Global Health Missions",
      quote: "Volunteering with Dr. Edumed opened my eyes to the power of medicine to transform communities. The experience has made me a better physician and person.",
      location: "Guatemala Mission 2023"
    },
    {
      name: "Michael Chen",
      role: "Medical Student",
      program: "Community Health Outreach",
      quote: "The community outreach program allowed me to apply my medical knowledge while serving those who need it most. It's been incredibly rewarding.",
      location: "Local Community Program"
    }
  ];

  const impactStats = [
    { number: "50,000+", label: "Lives Touched" },
    { number: "25", label: "Countries Served" },
    { number: "500+", label: "Active Volunteers" },
    { number: "15", label: "Years of Service" }
  ];

  const applicationSteps = [
    {
      step: "01",
      title: "Choose Your Program",
      description: "Select the volunteer program that matches your skills and availability"
    },
    {
      step: "02", 
      title: "Submit Application",
      description: "Complete our application form with your background and preferences"
    },
    {
      step: "03",
      title: "Interview & Training",
      description: "Participate in interview process and complete required training modules"
    },
    {
      step: "04",
      title: "Start Volunteering",
      description: "Begin your volunteer journey and make a meaningful impact"
    }
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center justify-center">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-overlay" />
        
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <div data-aos="fade-up" data-aos-delay="100">
            <Badge className="mb-6 bg-white/20 text-white border-white/30 text-lg px-6 py-2">
              <Heart className="h-4 w-4 mr-2" />
              Volunteer Programs
            </Badge>
          </div>
          
          <h1 
            className="text-hero font-bold mb-6 leading-tight max-w-4xl mx-auto"
            data-aos="fade-up"
            data-aos-delay="200"
          >
            Serve Others, Transform
            <span className="block text-gradient bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
              Your Medical Journey
            </span>
          </h1>
          
          <p 
            className="text-xl text-white/90 mb-8 max-w-3xl mx-auto leading-relaxed"
            data-aos="fade-up"
            data-aos-delay="300"
          >
            Join our global community of healthcare volunteers making a difference worldwide. 
            Gain invaluable experience while providing essential medical care to those who need it most.
          </p>
          
          <div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            data-aos="fade-up"
            data-aos-delay="400"
          >
            <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold text-lg px-8">
              Apply to Volunteer
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-primary font-semibold text-lg px-8"
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Impact Stats */}
      <section className="py-16 bg-white relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12" data-aos="fade-up">
            <h2 className="text-2xl font-bold mb-4">Our Global Impact</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Together, our volunteers have made a meaningful difference in communities around the world.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {impactStats.map((stat, index) => (
              <div 
                key={stat.label}
                className="text-center"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <div className="text-3xl font-bold text-primary mb-2">{stat.number}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Volunteer Programs */}
      <section className="section-padding bg-gradient-soft">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16" data-aos="fade-up">
            <Badge className="mb-6 bg-primary/10 text-primary">Volunteer Opportunities</Badge>
            <h2 className="text-xl-heading mb-6">
              Choose Your
              <span className="text-primary"> Service Path</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              We offer diverse volunteer opportunities to match your skills, interests, and availability. 
              Find the perfect way to make a difference.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {programs.map((program, index) => (
              <Card 
                key={index}
                className={`group hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1 border-card-border ${program.featured ? 'ring-2 ring-primary/20' : ''}`}
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                {program.featured && (
                  <div className="bg-gradient-primary text-white px-4 py-2 text-sm font-semibold">
                    ⭐ Featured Program
                  </div>
                )}
                <CardContent className="p-6">
                  <h3 className="font-bold text-xl mb-3 group-hover:text-primary transition-colors">
                    {program.title}
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{program.location}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{program.duration}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{program.commitment}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <BookOpen className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">Next: {program.nextMission}</span>
                    </div>
                  </div>

                  <p className="text-muted-foreground mb-4">
                    {program.description}
                  </p>

                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">Requirements:</h4>
                    <ul className="space-y-1">
                      {program.requirements.map((req, idx) => (
                        <li key={idx} className="flex items-start space-x-2">
                          <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-muted-foreground">{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button className="w-full bg-gradient-primary text-white hover:opacity-90">
                    Apply for This Program
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="section-padding bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16" data-aos="fade-up">
            <Badge className="mb-6 bg-primary/10 text-primary">Volunteer Benefits</Badge>
            <h2 className="text-xl-heading mb-6">
              Why Volunteer
              <span className="text-primary"> With Us</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Volunteering with Dr. Edumed offers more than just the satisfaction of helping others. 
              It's a transformative experience that enriches your professional and personal life.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {benefits.map((benefit, index) => (
              <Card 
                key={index}
                className="group hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1 border-card-border"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <CardContent className="p-8">
                  <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 bg-gradient-primary rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                      <benefit.icon className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-xl mb-3 group-hover:text-primary transition-colors">
                        {benefit.title}
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {benefit.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section-padding bg-gradient-soft">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16" data-aos="fade-up">
            <Badge className="mb-6 bg-primary/10 text-primary">Volunteer Stories</Badge>
            <h2 className="text-xl-heading mb-6">
              Hear from Our
              <span className="text-primary"> Volunteers</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Discover how volunteering has transformed the lives and careers of our dedicated volunteers.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card 
                key={index}
                className="group hover:shadow-card-hover transition-all duration-300 border-card-border"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <CardContent className="p-8">
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center">
                      <Stethoscope className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{testimonial.name}</h3>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                      <p className="text-xs text-primary">{testimonial.program}</p>
                    </div>
                  </div>
                  <blockquote className="text-muted-foreground italic mb-4">
                    "{testimonial.quote}"
                  </blockquote>
                  <p className="text-sm text-muted-foreground">
                    {testimonial.location}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Application Process */}
      <section className="section-padding bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16" data-aos="fade-up">
            <Badge className="mb-6 bg-white/20 text-white border-white/30">Application Process</Badge>
            <h2 className="text-xl-heading mb-6">
              Simple Steps to Start Volunteering
            </h2>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Getting started as a volunteer is easy. Follow these simple steps to begin your service journey.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {applicationSteps.map((step, index) => (
              <div 
                key={index}
                className="text-center"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <div className="w-16 h-16 bg-white text-primary rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-xl">
                  {step.step}
                </div>
                <h3 className="font-semibold text-lg mb-2">{step.title}</h3>
                <p className="text-white/80 text-sm">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="relative py-20 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${educationBg})` }}
        />
        <div className="absolute inset-0 bg-gradient-overlay" />
        
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <div data-aos="fade-up">
            <h2 className="text-xl-heading mb-6">
              Ready to Make a
              <span className="block">Difference?</span>
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Join our community of dedicated healthcare volunteers and help us transform lives 
              while advancing your own medical journey.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold text-lg px-8">
                Apply Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-primary font-semibold text-lg px-8"
              >
                Contact Volunteer Coordinator
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Volunteering;