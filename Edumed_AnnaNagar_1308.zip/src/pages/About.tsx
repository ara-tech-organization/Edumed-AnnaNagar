import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Award, 
  Users, 
  BookOpen, 
  Globe,
  CheckCircle,
  ArrowRight,
  Stethoscope,
  Heart,
  Brain,
  Shield,
  Target
} from 'lucide-react';

// Import images
import heroImage from '@/assets/hero-medical.jpg';
import educationBg from '@/assets/education-bg.jpg';

const About = () => {
  const values = [
    {
      icon: Heart,
      title: "Compassionate Care",
      description: "We instill the values of empathy and compassionate patient care in every healthcare professional we train."
    },
    {
      icon: Brain,
      title: "Scientific Excellence",
      description: "Our curriculum is built on the latest medical research and evidence-based practices."
    },
    {
      icon: Shield,
      title: "Ethical Practice",
      description: "We emphasize the highest standards of medical ethics and professional integrity."
    },
    {
      icon: Target,
      title: "Precision Medicine",
      description: "Training future doctors in personalized medicine and precision healthcare delivery."
    }
  ];

  const achievements = [
    { number: "25+", label: "Years of Excellence" },
    { number: "15,000+", label: "Graduates Worldwide" },
    { number: "500+", label: "Expert Faculty" },
    { number: "98%", label: "Employment Rate" }
  ];

  const leadership = [
    {
      name: "Dr. Michael Anderson",
      position: "Dean & Chief Medical Officer",
      specialization: "Cardiothoracic Surgery",
      experience: "30+ years",
      achievements: "Published 200+ research papers"
    },
    {
      name: "Dr. Sarah Chen",
      position: "Director of Medical Education",
      specialization: "Internal Medicine",
      experience: "25+ years", 
      achievements: "Curriculum innovation award recipient"
    },
    {
      name: "Dr. James Rodriguez",
      position: "Research Director",
      specialization: "Emergency Medicine",
      experience: "20+ years",
      achievements: "Leading emergency care protocols"
    }
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center justify-center">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-overlay" />
        
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <div data-aos="fade-up" data-aos-delay="100">
            <Badge className="mb-6 bg-white/20 text-white border-white/30 text-lg px-6 py-2">
              About Dr. Edumed
            </Badge>
          </div>
          
          <h1 
            className="text-hero font-bold mb-6 leading-tight max-w-4xl mx-auto"
            data-aos="fade-up"
            data-aos-delay="200"
          >
            Shaping the Future of
            <span className="block text-gradient bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
              Medical Excellence
            </span>
          </h1>
          
          <p 
            className="text-xl text-white/90 mb-8 max-w-3xl mx-auto leading-relaxed"
            data-aos="fade-up"
            data-aos-delay="300"
          >
            For over 25 years, Dr. Edumed Medical Academy has been at the forefront of medical education, 
            training compassionate healthcare professionals who make a meaningful difference in communities worldwide.
          </p>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="section-padding bg-gradient-soft">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div data-aos="fade-right">
              <Badge className="mb-6 bg-primary/10 text-primary">Our Mission</Badge>
              <h2 className="text-xl-heading mb-6">
                Empowering Healthcare
                <span className="text-primary"> Professionals</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                Our mission is to provide world-class medical education that combines cutting-edge 
                knowledge with hands-on clinical experience, preparing healthcare professionals to 
                excel in an ever-evolving medical landscape.
              </p>
              <div className="space-y-4 mb-8">
                {[
                  "Foster innovation in medical practice",
                  "Promote evidence-based healthcare",
                  "Develop compassionate medical leaders",
                  "Advance global health initiatives"
                ].map((mission, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-primary" />
                    <span>{mission}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div data-aos="fade-left" className="relative">
              <img 
                src={educationBg} 
                alt="Medical Mission" 
                className="rounded-2xl shadow-elegant w-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Core Values Section */}
      <section className="section-padding bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16" data-aos="fade-up">
            <Badge className="mb-6 bg-primary/10 text-primary">Our Core Values</Badge>
            <h2 className="text-xl-heading mb-6">
              Values That Guide
              <span className="text-primary"> Our Mission</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              These fundamental principles shape every aspect of our medical education 
              and guide our students toward becoming exemplary healthcare professionals.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <Card 
                key={index}
                className="group hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1 border-card-border"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <CardContent className="p-8">
                  <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 bg-gradient-primary rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                      <value.icon className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-xl mb-3 group-hover:text-primary transition-colors">
                        {value.title}
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {value.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="section-padding bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16" data-aos="fade-up">
            <Badge className="mb-6 bg-white/20 text-white border-white/30">Our Achievements</Badge>
            <h2 className="text-xl-heading mb-6">
              Excellence in Numbers
            </h2>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Our commitment to excellence is reflected in our achievements and the success of our graduates.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <div 
                key={achievement.label}
                className="text-center"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <div className="text-4xl font-bold mb-2">{achievement.number}</div>
                <div className="text-white/80">{achievement.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Leadership Team Section */}
      <section className="section-padding bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16" data-aos="fade-up">
            <Badge className="mb-6 bg-primary/10 text-primary">Leadership Team</Badge>
            <h2 className="text-xl-heading mb-6">
              Meet Our
              <span className="text-primary"> Medical Leaders</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our distinguished faculty brings decades of clinical experience and academic excellence 
              to guide the next generation of healthcare professionals.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {leadership.map((leader, index) => (
              <Card 
                key={index}
                className="group hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1 border-card-border overflow-hidden"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <div className="h-48 bg-gradient-primary relative overflow-hidden">
                  <div className="absolute inset-0 bg-white/10" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto">
                      <Stethoscope className="h-8 w-8 text-primary" />
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">
                    {leader.name}
                  </h3>
                  <p className="text-primary font-semibold mb-2">
                    {leader.position}
                  </p>
                  <p className="text-muted-foreground text-sm mb-3">
                    {leader.specialization}
                  </p>
                  <div className="space-y-1 text-sm">
                    <p><span className="font-medium">Experience:</span> {leader.experience}</p>
                    <p><span className="font-medium">Achievement:</span> {leader.achievements}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* History Section */}
      <section className="section-padding bg-gradient-soft">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div data-aos="fade-right" className="relative">
              <img 
                src={heroImage} 
                alt="Dr. Edumed History" 
                className="rounded-2xl shadow-elegant w-full"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-xl shadow-card">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center">
                    <Award className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <div className="font-semibold">Since 1999</div>
                    <div className="text-sm text-muted-foreground">Trusted Excellence</div>
                  </div>
                </div>
              </div>
            </div>

            <div data-aos="fade-left">
              <Badge className="mb-6 bg-primary/10 text-primary">Our History</Badge>
              <h2 className="text-xl-heading mb-6">
                A Legacy of
                <span className="text-primary"> Medical Excellence</span>
              </h2>
              <div className="space-y-6">
                <div className="border-l-4 border-primary pl-6">
                  <h3 className="font-semibold text-lg mb-2">1999: Foundation</h3>
                  <p className="text-muted-foreground">
                    Dr. Edumed Medical Academy was founded with a vision to revolutionize medical education 
                    through innovative teaching methodologies and hands-on clinical training.
                  </p>
                </div>
                
                <div className="border-l-4 border-primary pl-6">
                  <h3 className="font-semibold text-lg mb-2">2005: International Recognition</h3>
                  <p className="text-muted-foreground">
                    Received international accreditation and began partnerships with leading medical 
                    institutions worldwide.
                  </p>
                </div>
                
                <div className="border-l-4 border-primary pl-6">
                  <h3 className="font-semibold text-lg mb-2">2015: Research Excellence</h3>
                  <p className="text-muted-foreground">
                    Established state-of-the-art research facilities and became a leading center 
                    for medical research and innovation.
                  </p>
                </div>
                
                <div className="border-l-4 border-primary pl-6">
                  <h3 className="font-semibold text-lg mb-2">2024: Future Ready</h3>
                  <p className="text-muted-foreground">
                    Pioneering digital health education and telemedicine training programs for 
                    the next generation of healthcare professionals.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-overlay" />
        
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <div data-aos="fade-up">
            <h2 className="text-xl-heading mb-6">
              Join Our Legacy of
              <span className="block">Medical Excellence</span>
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Be part of a tradition that has shaped thousands of healthcare professionals 
              and continues to advance the future of medicine.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold text-lg px-8">
                Apply Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-primary font-semibold text-lg px-8"
              >
                Contact Admissions
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;