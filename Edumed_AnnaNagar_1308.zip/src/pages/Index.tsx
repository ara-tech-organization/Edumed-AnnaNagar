import React from "react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import CountUp from "react-countup";
import { useInView } from "react-intersection-observer";
import TestimonialCarousel from "@/components/ui/testimonial-carousel";
import CourseCard from "@/components/ui/course-card";
import { Swiper, SwiperSlide } from "swiper/react";
import { EffectCoverflow, Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/effect-coverflow";
import "swiper/css/navigation";
import {
  ArrowLeft,
  ArrowRight,
  Award,
  Users,
  BookOpen,
  Star,
  GraduationCap,
  Briefcase,
  Scale,
  Rocket
} from "lucide-react";

// Import images
import heroImage from "@/assets/About Us.png";
import medicalPattern from "@/assets/medical-pattern.jpg";
import HairFollicleIcon from "@/assets/blood-donation-svgrepo-com.svg";
import medicalpills from "@/assets/pills-pill-svgrepo-com.svg";
import educationBg from "@/assets/education-bg.jpg";
import underlineSvg from "@/assets/dual-underline.svg"
import Facialinjectables from "@/assets/Facial-Aesthetics.png";
import ClinicalCosmetology from "@/assets/Clinical-Cosmetology.png";
import DiplomaClinicalCosmetology from "@/assets/Diploma-Clinical-Cosmetology.png";
import FacialAesthetics from "@/assets/Facial-Aesthetics.png";
import Makeup from "@/assets/Makeup.png";

import { useNavigate } from "react-router-dom";

const Index = () => {
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.3 });
  const navigate = useNavigate();
  const [swiperRef, setSwiperRef] = useState(null);

  const testimonials = [
    {
      id: 1,
      name: "Dr. Sarah Johnson",
      role: "Resident Physician",
      image: "",
      rating: 5,
      content:
        "The internship program at Dr. Edumed has been transformative. The hands-on experience and mentorship I received here shaped my medical career.",
      location: "New York Medical Center",
    },
    {
      id: 2,
      name: "Marcus Chen",
      role: "Medical Student",
      image: "",
      rating: 5,
      content:
        "Outstanding faculty and state-of-the-art facilities. The clinical exposure here is unmatched, and the learning environment is truly exceptional.",
      location: "Johns Hopkins University",
    },
    {
      id: 3,
      name: "Dr. Emily Rodriguez",
      role: "Emergency Medicine",
      image: "",
      rating: 5,
      content:
        "Dr. Edumed's training program prepared me thoroughly for real-world medical challenges. The skills I learned here are invaluable.",
      location: "Boston General Hospital",
    },
  ];

 const featuredCourses = [
  {
    id: 1,
    image: Facialinjectables,
    title: "Master in Facial Injectables",
    description:
      "This postgraduate program trains medical professionals in Botox, fillers, and threads, blending theory with hands-on training.",
    tag: "Postgraduate",
  },
  {
    id: 2,
    image: DiplomaClinicalCosmetology,
    title: "PG Diploma in Clinical Cosmetology",
    description:
      "Advanced cosmetic treatment training for skin, hair, and laser with the latest equipment and techniques.",
    tag: "Diploma",
  },
  {
    id: 3,
    image: ClinicalCosmetology,
    title: "Fellowship in Clinical Cosmetology",
    description:
      "Focused on advanced skincare, anti-aging, and non-surgical techniques with practical learning.",
    tag: "Fellowship",
  },
  {
    id: 4,
    image: FacialAesthetics,
    title: "Fellowship in Facial Aesthetics",
    description:
      "Hair & skin science, cosmetic procedures, and ethics in aesthetic practice for professionals.",
    tag: "Fellowship",
  },
  {
    id: 5,
    image: Makeup,
    title: "Workshop in Semi-Permanent Makeup (SPMU)",
    description:
      "Covers microblading, powder brows, lip blush, eyeliner enhancement, and aftercare.",
    tag: "Workshop",
  },
];


  const stats = [
    { number: 15000, suffix: "+", label: "Graduates", icon: Users },
    { number: 500, suffix: "+", label: "Expert Faculty", icon: Award },
    { number: 200, suffix: "+", label: "Courses", icon: BookOpen },
    { number: 98, suffix: "%", label: "Success Rate", icon: Star },
  ];

  const specialties = [
    {
      icon: GraduationCap,
      title: "In-Depth Expert Training",
      description:
        "Learn from highly qualified professionals with decades of hands-on experience.",
    },
    {
      icon: Award,
      title: "Accredited Certification",
      description:
        "Government and internationally recognized certificates for your professional credibility.",
    },
    {
      icon: Briefcase,
      title: "Guaranteed Placement",
      description:
        "Placement assistance with a refund policy for complete peace of mind.",
    },
    {
      icon: Scale,
      title: "Medico-Legal & Vendor Support",
      description:
        "Guidance on legal compliance and connections to trusted medical vendors.",
    },
    {
      icon: Rocket,
      title: "Business Launch Assistance",
      description:
        "End-to-end support to help you establish and grow your own medical practice.",
    },
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#e8f6f7] via-white to-[#f0fbfb] overflow-hidden">
        {/* Gradient Blobs */}
        <div className="absolute top-[-8rem] left-[-8rem] w-[28rem] h-[28rem] bg-gradient-to-br from-[#056a7a] via-[#04bfbf] to-[#82e0e0] rounded-full blur-[140px] opacity-30"></div>
        <div className="absolute bottom-[-10rem] right-[-10rem] w-[36rem] h-[36rem] bg-gradient-to-tr from-[#04bfbf] via-[#aaf4f4] to-transparent rounded-full blur-[180px] opacity-25"></div>

        {/* Dotted Pattern Overlay */}
        <div
          className="absolute inset-0 opacity-[0.12]"
          style={{
            backgroundImage:
              "radial-gradient(circle, rgba(5,106,122,0.3) 1px, transparent 1px)",
            backgroundSize: "22px 22px",
          }}
        ></div>

        <div className="container mx-auto px-6 lg:px-10 py-20 lg:py-32 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center relative z-10">
          {/* Left Content */}
          <div className="order-2 lg:order-1 max-w-xl">
            <div className="inline-block bg-[#056a7a]/10 text-[#056a7a] px-4 py-1 rounded-full text-sm font-medium tracking-wider mb-6">
              ✨ Excellence in Medical Education
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-tight text-[#032c40]">
              Empowering Future
              <span className="block text-transparent bg-gradient-to-r from-[#056a7a] via-[#04bfbf] to-[#7de0e0] bg-clip-text">
                Healthcare Leaders
              </span>
            </h1>

            <p className="mt-6 text-lg sm:text-xl text-gray-700 leading-relaxed">
              Join thousands of medical professionals who have advanced their
              careers through our world-class training programs, internships,
              and hands-on clinical experience.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row gap-4">
              <button className="bg-[#056a7a] text-white font-medium px-8 py-3 rounded-full hover:bg-[#045863] transition duration-300">
                Explore Programs
              </button>
            </div>
          </div>

          {/* Right Image */}
          <div className="relative order-1 lg:order-2 flex justify-center lg:justify-end">
            <div className="relative z-10">
              <img
                src={heroImage}
                alt="Medical Education"
                className="rounded-[1.5rem] w-full max-w-[1000px] lg:max-w-[1000px] object-contain"
              />
            </div>

            {/* Floating Icon 1 */}
            <div className="absolute -top-10 -left-10 w-18 h-18 bg-white/90 rounded-full flex items-center justify-center animate-[float_6s_ease-in-out_infinite] z-20 shadow-lg">
              <img src={HairFollicleIcon} alt="Icon 1" className="h-10 w-10" />
            </div>

            {/* Floating Icon 2 */}
            <div className="absolute bottom-6 -right-8 w-18 h-18 bg-white/90 rounded-full flex items-center justify-center animate-[float_6s_ease-in-out_infinite] [animation-delay:2s] z-20">
              <img src={medicalpills} alt="Icon 2" className="h-10 w-10" />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-5"
          style={{ backgroundImage: `url(${medicalPattern})` }}
        />
        <div className="container mx-auto px-4 relative z-10">
          <div ref={ref} className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div
                key={stat.label}
                className="text-center"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <stat.icon className="h-8 w-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-primary mb-2">
                  {inView ? (
                    <CountUp
                      end={stat.number}
                      duration={2}
                      suffix={stat.suffix}
                    />
                  ) : (
                    "0"
                  )}
                </div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Preview Section */}
      <section className="relative py-16 lg:py-24 bg-white overflow-hidden">
        <div className="container mx-auto px-4 grid lg:grid-cols-2 gap-14 items-center">

          {/* Left: Image */}
          <div data-aos="fade-right" className="relative order-1">
            <img
              src={heroImage}
              alt="DrEduMed Anna Nagar Chennai"
              className="rounded-2xl shadow-lg w-full object-cover"
            />
            {/* Decorative Shape */}
            <div className="absolute -bottom-6 -right-6 w-40 h-40 bg-primary/10 rounded-full blur-2xl"></div>
          </div>

          {/* Right: Content */}
          <div data-aos="fade-left" className="order-2">
            {/* Heading with underline */}
            <h2 className="text-3xl md:text-4xl font-bold mb-4 relative inline-block text-center">
              About DrEduMed Anna Nagar Chennai
              <img
                src={underlineSvg}
                alt="underline"
                className="absolute left-1/2 bottom-0 -translate-x-1/2 translate-y-6 w-48 md:w-64 z-0"
              />
            </h2>

            {/* Paragraphs */}
            <p className="text-lg text-gray-600 mb-6 mt-4">
              DrEduMed is a prestigious institution dedicated to providing world-class
              aesthetic training. Our Anna Nagar Chennai branch offers comprehensive
              programs that cater to both beginners and professionals looking to refine
              their skills.
            </p>
            <p className="text-lg text-gray-600 mb-8">
              With expert trainers and state-of-the-art facilities, we ensure that our
              students are prepared to excel in the field of aesthetics.
            </p>

            {/* Button */}
            <button
              onClick={() => navigate("/about")}
              className="inline-flex items-center bg-gradient-to-r from-primary to-primary-dark text-white font-medium px-6 py-3 rounded-full shadow-md hover:shadow-lg transition"
            >
              Learn More
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Specialties Section */}
      <section className="py-20 bg-gradient-to-b from-white to-primary/5">
        <div className="container mx-auto px-4">
          {/* Heading */}
          <div className="text-center mb-16" data-aos="fade-up">
            <Badge className="mb-6 bg-primary/10 text-primary">
              Why Choose Dr. Edumed?
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Why Choose <span className="text-primary">Dr. Edumed?</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              We combine expertise, global recognition, and career-focused support
              to help you excel in the medical field.
            </p>
          </div>

          {/* Vertical List */}
          <div className="space-y-10 max-w-3xl mx-auto relative">
            {/* Vertical line */}
            <div className="absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-primary/40 to-transparent" />

            {specialties.map((item, index) => (
              <div
                key={index}
                className="flex items-start space-x-6 relative"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                {/* Icon bubble */}
                <div className="relative z-10 flex-shrink-0 w-16 h-16 rounded-full bg-gradient-to-tr from-primary to-primary/70 flex items-center justify-center shadow-lg">
                  <item.icon className="h-8 w-8 text-white" />
                </div>

                {/* Text content */}
                <div>
                  <h3 className="font-semibold text-xl mb-2 text-gray-900">
                    {item.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Courses Section */}
  <section className="section-padding bg-gradient-to-b from-white to-primary/5">
  <div className="container mx-auto px-4 flex flex-col lg:flex-row items-center gap-12">
    
    {/* LEFT CONTENT */}
    <div className="lg:w-1/2 text-center lg:text-left" data-aos="fade-right">
      <Badge className="mb-6 bg-primary/10 text-primary">
        Featured Courses
      </Badge>
      <h2 className="text-4xl md:text-5xl font-bold mb-6">
        Most Popular <span className="text-primary">Training Programs</span>
      </h2>
      <p className="text-lg text-muted-foreground max-w-xl mb-8">
        Explore our most in-demand courses designed by top medical professionals to advance your healthcare career.
      </p>

      {/* Navigation Arrows */}
      <div className="flex gap-4 justify-center lg:justify-start">
        <Button
          variant="outline"
          size="icon"
          onClick={() => swiperRef?.slidePrev()}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={() => swiperRef?.slideNext()}
        >
          <ArrowRight className="h-5 w-5" />
        </Button>
      </div>
    </div>

    {/* RIGHT CAROUSEL */}
    <div className="lg:w-1/2 lg:pl-8 w-full" data-aos="fade-left">
      <Swiper
        onSwiper={setSwiperRef}
        effect="coverflow"
        grabCursor={true}
        centeredSlides={true}
        loop={true}
        slidesPerView={1.05} // Mobile default
        breakpoints={{
          640: { slidesPerView: 1.2 },   // Small tablets
          768: { slidesPerView: 1.4 },   // Tablets
          1024: { slidesPerView: 1.6 },  // Desktops
          1440: { slidesPerView: 1.8 },  // Large desktops
        }}
        coverflowEffect={{
          rotate: 0,
          stretch: 0,
          depth: 180,
          modifier: 1.5,
          scale: 1,
          slideShadows: false,
        }}
        modules={[EffectCoverflow, Navigation]}
        className="w-full"
      >
        {featuredCourses.map((course) => (
          <SwiperSlide key={course.id}>
            <div className="bg-white rounded-2xl overflow-hidden shadow-lg transition-transform hover:scale-[1.02] h-[420px] sm:h-[440px] md:h-[460px]">
              <img
                src={course.image}
                alt={course.title}
                className="w-full h-[220px] sm:h-[240px] md:h-[260px] object-cover"
              />
              <div className="p-5">
                <Badge className="mb-3 bg-primary/90 text-white">{course.tag}</Badge>
                <h3 className="font-semibold text-lg mb-2">{course.title}</h3>
                <p className="text-sm text-muted-foreground">{course.description}</p>
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  </div>
</section>


      {/* Testimonials Section */}
      <section className="section-padding bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left side - Image */}
            <div data-aos="fade-right">
              <div className="relative">
                <img
                  src={heroImage}
                  alt="Happy Medical Students"
                  className="rounded-2xl shadow-elegant w-full"
                />
                <div className="absolute -top-6 -right-6 bg-white p-4 rounded-xl shadow-card">
                  <div className="flex items-center space-x-2">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className="h-4 w-4 text-yellow-400 fill-current"
                        />
                      ))}
                    </div>
                    <span className="font-semibold">4.9/5</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Student Rating
                  </div>
                </div>
              </div>
            </div>

            {/* Right side - Testimonials */}
            <div data-aos="fade-left">
              <Badge className="mb-6 bg-primary/10 text-primary">
                Student Testimonials
              </Badge>
              <h2 className="text-xl-heading mb-8">
                What Our Students
                <span className="text-primary"> Say About Us</span>
              </h2>
              <TestimonialCarousel testimonials={testimonials} />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-overlay" />

        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <div data-aos="fade-up">
            <h2 className="text-xl-heading mb-6">
              Ready to Start Your
              <span className="block">Medical Journey?</span>
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Join thousands of healthcare professionals who have advanced their
              careers with Dr. Edumed Medical Academy.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-white text-primary hover:bg-white/90 font-semibold text-lg px-8"
              >
                Apply Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-primary font-semibold text-lg px-8"
              >
                Schedule Consultation
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
