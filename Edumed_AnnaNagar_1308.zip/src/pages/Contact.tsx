import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock,
  Send,
  MessageSquare,
  Users,
  Calendar,
  Globe
} from 'lucide-react';

// Import images
import heroImage from '@/assets/hero-medical.jpg';

const Contact = () => {
  const contactInfo = [
    {
      icon: Phone,
      title: "Phone",
      details: ["+1 (555) 123-4567", "+1 (555) 123-4568 (Emergency)"],
      available: "24/7 Support Available"
    },
    {
      icon: Mail,
      title: "Email",
      details: ["info@dredumed.com", "admissions@dredumed.com"],
      available: "Response within 24 hours"
    },
    {
      icon: MapPin,
      title: "Address",
      details: ["123 Medical Center Drive", "Healthcare District, NY 10001"],
      available: "Visitor hours: 8 AM - 6 PM"
    },
    {
      icon: Clock,
      title: "Office Hours",
      details: ["Monday - Friday: 8:00 AM - 6:00 PM", "Saturday: 9:00 AM - 2:00 PM"],
      available: "Closed on Sundays"
    }
  ];

  const departments = [
    {
      icon: Users,
      name: "Admissions Office",
      email: "admissions@dredumed.com",
      phone: "+1 (555) 123-4567",
      description: "Information about programs, applications, and enrollment"
    },
    {
      icon: Calendar,
      name: "Student Services",
      email: "students@dredumed.com", 
      phone: "+1 (555) 123-4568",
      description: "Support for current students and academic assistance"
    },
    {
      icon: Globe,
      name: "International Programs",
      email: "international@dredumed.com",
      phone: "+1 (555) 123-4569",
      description: "Global opportunities and international student support"
    },
    {
      icon: MessageSquare,
      name: "General Inquiries",
      email: "info@dredumed.com",
      phone: "+1 (555) 123-4567",
      description: "General questions and information requests"
    }
  ];

  const faqs = [
    {
      question: "What are the admission requirements?",
      answer: "Admission requirements vary by program. Generally, we require a relevant undergraduate degree, minimum GPA, letters of recommendation, and completion of prerequisite courses."
    },
    {
      question: "Do you offer financial aid?",
      answer: "Yes, we offer various financial aid options including scholarships, grants, and payment plans. Contact our financial aid office for personalized assistance."
    },
    {
      question: "Can international students apply?",
      answer: "Absolutely! We welcome international students and provide comprehensive support including visa assistance and orientation programs."
    },
    {
      question: "What is the duration of programs?",
      answer: "Program duration varies from 6 weeks for specialized courses to 24 months for comprehensive programs. Each program page contains specific duration information."
    }
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[70vh] flex items-center justify-center">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-overlay" />
        
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <div data-aos="fade-up" data-aos-delay="100">
            <Badge className="mb-6 bg-white/20 text-white border-white/30 text-lg px-6 py-2">
              Contact Us
            </Badge>
          </div>
          
          <h1 
            className="text-hero font-bold mb-6 leading-tight max-w-4xl mx-auto"
            data-aos="fade-up"
            data-aos-delay="200"
          >
            Get in Touch with
            <span className="block text-gradient bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
              Dr. Edumed Academy
            </span>
          </h1>
          
          <p 
            className="text-xl text-white/90 mb-8 max-w-3xl mx-auto leading-relaxed"
            data-aos="fade-up"
            data-aos-delay="300"
          >
            We're here to help you begin your medical journey. Reach out to us for information 
            about our programs, admissions, or any questions you may have.
          </p>
        </div>
      </section>

      {/* Contact Information Cards */}
      <section className="section-padding bg-gradient-soft">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16" data-aos="fade-up">
            <Badge className="mb-6 bg-primary/10 text-primary">Contact Information</Badge>
            <h2 className="text-xl-heading mb-6">
              Multiple Ways to
              <span className="text-primary"> Reach Us</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Choose the most convenient way to contact us. We're committed to providing 
              prompt and helpful responses to all inquiries.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {contactInfo.map((info, index) => (
              <Card 
                key={index}
                className="group hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1 border-card-border text-center"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-gradient-primary rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                    <info.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="font-semibold text-lg mb-3 group-hover:text-primary transition-colors">
                    {info.title}
                  </h3>
                  <div className="space-y-1 mb-3">
                    {info.details.map((detail, idx) => (
                      <p key={idx} className="text-muted-foreground">
                        {detail}
                      </p>
                    ))}
                  </div>
                  <p className="text-sm text-primary font-medium">
                    {info.available}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form & Departments */}
      <section className="section-padding bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div data-aos="fade-right">
              <h2 className="text-2xl font-bold mb-6">Send Us a Message</h2>
              <p className="text-muted-foreground mb-8">
                Fill out the form below and we'll get back to you as soon as possible. 
                For urgent matters, please call us directly.
              </p>

              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">First Name</label>
                    <Input placeholder="Enter your first name" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Last Name</label>
                    <Input placeholder="Enter your last name" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Email Address</label>
                  <Input type="email" placeholder="Enter your email address" />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Phone Number</label>
                  <Input type="tel" placeholder="Enter your phone number" />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Subject</label>
                  <Input placeholder="What is this regarding?" />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Message</label>
                  <Textarea 
                    rows={6}
                    placeholder="Please provide details about your inquiry..."
                  />
                </div>

                <Button size="lg" className="w-full bg-gradient-primary text-white hover:opacity-90">
                  <Send className="mr-2 h-5 w-5" />
                  Send Message
                </Button>
              </form>
            </div>

            {/* Departments */}
            <div data-aos="fade-left">
              <h2 className="text-2xl font-bold mb-6">Contact by Department</h2>
              <p className="text-muted-foreground mb-8">
                For specific inquiries, you can contact our specialized departments directly 
                for faster and more targeted assistance.
              </p>

              <div className="space-y-4">
                {departments.map((dept, index) => (
                  <Card 
                    key={index}
                    className="group hover:shadow-card-hover transition-all duration-300 border-card-border"
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center flex-shrink-0">
                          <dept.icon className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                            {dept.name}
                          </h3>
                          <p className="text-muted-foreground text-sm mb-3">
                            {dept.description}
                          </p>
                          <div className="space-y-1">
                            <div className="flex items-center space-x-2">
                              <Mail className="h-4 w-4 text-muted-foreground" />
                              <span className="text-sm">{dept.email}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Phone className="h-4 w-4 text-muted-foreground" />
                              <span className="text-sm">{dept.phone}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="section-padding bg-gradient-soft">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16" data-aos="fade-up">
            <Badge className="mb-6 bg-primary/10 text-primary">Frequently Asked Questions</Badge>
            <h2 className="text-xl-heading mb-6">
              Common Questions
              <span className="text-primary"> & Answers</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Find quick answers to the most commonly asked questions about our programs and services.
            </p>
          </div>

          <div className="max-w-3xl mx-auto space-y-4">
            {faqs.map((faq, index) => (
              <Card 
                key={index}
                className="border-card-border"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <CardContent className="p-6">
                  <h3 className="font-semibold text-lg mb-3">
                    {faq.question}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12" data-aos="fade-up">
            <p className="text-muted-foreground mb-4">
              Don't see your question answered here?
            </p>
            <Button className="bg-gradient-primary text-white hover:opacity-90">
              Contact Our Support Team
            </Button>
          </div>
        </div>
      </section>

      {/* Map & Location */}
      <section className="section-padding bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div data-aos="fade-right">
              <Badge className="mb-6 bg-primary/10 text-primary">Visit Our Campus</Badge>
              <h2 className="text-xl-heading mb-6">
                Located in the Heart of the
                <span className="text-primary"> Medical District</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                Our state-of-the-art campus is conveniently located in the healthcare district, 
                providing easy access to major medical centers and research facilities.
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-start space-x-3">
                  <MapPin className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <p className="font-semibold">Main Campus</p>
                    <p className="text-muted-foreground">
                      123 Medical Center Drive<br />
                      Healthcare District, NY 10001
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Clock className="h-5 w-5 text-primary mt-0.5" />
                  <div>
                    <p className="font-semibold">Campus Hours</p>
                    <p className="text-muted-foreground">
                      Monday - Friday: 7:00 AM - 10:00 PM<br />
                      Saturday - Sunday: 8:00 AM - 6:00 PM
                    </p>
                  </div>
                </div>
              </div>

              <Button className="bg-gradient-primary text-white hover:opacity-90">
                Schedule Campus Tour
              </Button>
            </div>

            <div data-aos="fade-left" className="relative">
              {/* Placeholder for map - in real implementation, you'd use Google Maps or similar */}
              <div className="w-full h-80 bg-gradient-soft rounded-2xl flex items-center justify-center shadow-elegant">
                <div className="text-center">
                  <MapPin className="h-16 w-16 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold text-lg mb-2">Interactive Map</h3>
                  <p className="text-muted-foreground">
                    Campus map and directions would be displayed here
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Contact */}
      <section className="py-12 bg-primary text-white">
        <div className="container mx-auto px-4" data-aos="fade-up">
          <div className="text-center">
            <h3 className="text-xl font-bold mb-4">Emergency Contact</h3>
            <p className="text-white/90 mb-4">
              For urgent medical or safety concerns on campus:
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold">
                <Phone className="mr-2 h-5 w-5" />
                Emergency: +1 (555) 911-HELP
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                Campus Security: +1 (555) 123-SAFE
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;