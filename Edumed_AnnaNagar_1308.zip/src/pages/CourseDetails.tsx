import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Clock, 
  Users, 
  Star, 
  BookOpen, 
  Calendar,
  CheckCircle,
  Play,
  Download,
  Share,
  Award,
  Target,
  Lightbulb
} from 'lucide-react';

// Import images
import educationBg from '@/assets/education-bg.jpg';

const CourseDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const handleEnrollClick = () => {
    navigate('/contact');
  };

  // Mock course data - in real app, this would come from API
  const course = {
    id: "advanced-surgery",
    title: "Advanced Surgical Techniques",
    description: "Master cutting-edge surgical procedures with hands-on training from world-renowned surgeons. This comprehensive program covers the latest minimally invasive techniques, robotic surgery, and precision medicine approaches.",
    fullDescription: "This intensive 12-week program is designed for experienced surgeons looking to advance their skills in modern surgical techniques. You'll learn from leading experts in the field and gain hands-on experience with the latest surgical technologies and methodologies.",
    image: educationBg,
    duration: "12 weeks",
    students: 245,
    rating: 4.9,
    reviews: 156,
    level: "Advanced",
    price: 2499,
    originalPrice: 3499,
    instructor: {
      name: "Dr. Michael Chen",
      title: "Chief of Surgery",
      experience: "20+ years",
      rating: 4.9,
      students: 2500,
      bio: "Dr. Chen is a board-certified surgeon with over 20 years of experience in advanced surgical techniques. He has performed over 5,000 successful surgeries and is a pioneer in minimally invasive procedures."
    },
    category: "Surgery",
    startDate: "February 15, 2024",
    endDate: "May 10, 2024",
    schedule: "Tuesdays & Thursdays, 6:00 PM - 8:00 PM EST",
    language: "English",
    certificate: "Professional Certificate",
    featured: true
  };

  const curriculum = [
    {
      week: 1,
      title: "Introduction to Advanced Surgical Techniques",
      topics: [
        "Modern surgical principles",
        "Patient safety protocols",
        "Surgical anatomy review",
        "Equipment overview"
      ]
    },
    {
      week: 2,
      title: "Minimally Invasive Surgery",
      topics: [
        "Laparoscopic techniques",
        "Endoscopic procedures",
        "Port placement strategies",
        "Complication management"
      ]
    },
    {
      week: 3,
      title: "Robotic Surgery Fundamentals",
      topics: [
        "Da Vinci system operation",
        "Console skills training",
        "Robotic suturing techniques",
        "Case selection criteria"
      ]
    },
    {
      week: 4,
      title: "Advanced Tissue Handling",
      topics: [
        "Precision dissection techniques",
        "Hemostasis methods",
        "Tissue preservation",
        "Microsurgical skills"
      ]
    }
  ];

  const learningOutcomes = [
    "Master advanced minimally invasive surgical techniques",
    "Perform robotic-assisted surgical procedures",
    "Implement precision medicine in surgical practice",
    "Manage complex surgical complications",
    "Utilize cutting-edge surgical technologies",
    "Apply evidence-based surgical protocols"
  ];

  const prerequisites = [
    "Medical degree (MD or equivalent)",
    "Completed surgical residency",
    "Board certification in surgery",
    "Minimum 3 years surgical experience",
    "Current medical license"
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-soft">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Course Info */}
            <div data-aos="fade-right">
              <div className="flex items-center space-x-3 mb-4">
                <Badge className="bg-primary/10 text-primary">{course.category}</Badge>
                <Badge variant="outline">{course.level}</Badge>
                {course.featured && (
                  <Badge className="bg-accent text-white">
                    <Award className="h-3 w-3 mr-1" />
                    Featured
                  </Badge>
                )}
              </div>
              
              <h1 className="text-xl-heading mb-4">
                {course.title}
              </h1>
              
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                {course.description}
              </p>

              {/* Course Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{course.duration}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{course.students} students</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Star className="h-4 w-4 text-yellow-400 fill-current" />
                  <span className="text-sm">{course.rating} ({course.reviews} reviews)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Starts {course.startDate.split(',')[0]}</span>
                </div>
              </div>

              {/* Instructor Info */}
              <div className="flex items-center space-x-4 mb-6 p-4 bg-white rounded-lg shadow-sm">
                <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold">
                    {course.instructor.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
                <div>
                  <h3 className="font-semibold">{course.instructor.name}</h3>
                  <p className="text-sm text-muted-foreground">{course.instructor.title}</p>
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                    <span>{course.instructor.experience}</span>
                    <span>•</span>
                    <span>{course.instructor.students} students taught</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-gradient-primary text-white hover:opacity-90 font-semibold flex-1"
                  onClick={handleEnrollClick}
                >
                  <BookOpen className="mr-2 h-5 w-5" />
                  Enroll Now - ${course.price}
                </Button>
                <Button size="lg" variant="outline" className="flex items-center">
                  <Share className="mr-2 h-4 w-4" />
                  Share
                </Button>
              </div>

              {course.originalPrice && (
                <div className="mt-4 flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground line-through">
                    Original price: ${course.originalPrice}
                  </span>
                  <Badge variant="destructive">
                    Save ${course.originalPrice - course.price}
                  </Badge>
                </div>
              )}
            </div>

            {/* Course Image & Video */}
            <div data-aos="fade-left" className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-elegant">
                <img 
                  src={course.image} 
                  alt={course.title}
                  className="w-full h-80 object-cover"
                />
                <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                  <Button size="lg" className="bg-white/90 text-primary hover:bg-white">
                    <Play className="mr-2 h-5 w-5" />
                    Preview Course
                  </Button>
                </div>
              </div>

              {/* Quick Info Card */}
              <Card className="absolute -bottom-6 -left-6 bg-white shadow-card">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
                      <Award className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-sm">Certificate Included</div>
                      <div className="text-xs text-muted-foreground">{course.certificate}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Course Details Tabs */}
      <section className="section-padding bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-12">
              {/* About This Course */}
              <div data-aos="fade-up">
                <h2 className="text-2xl font-bold mb-6">About This Course</h2>
                <p className="text-muted-foreground leading-relaxed mb-6">
                  {course.fullDescription}
                </p>
                <p className="text-muted-foreground leading-relaxed">
                  Our curriculum is designed in collaboration with leading medical institutions 
                  and follows the latest industry standards. You'll have access to state-of-the-art 
                  simulation labs and real-world case studies that prepare you for the challenges 
                  of modern surgical practice.
                </p>
              </div>

              {/* Learning Outcomes */}
              <div data-aos="fade-up">
                <h2 className="text-2xl font-bold mb-6 flex items-center">
                  <Target className="h-6 w-6 mr-2 text-primary" />
                  What You'll Learn
                </h2>
                <div className="grid md:grid-cols-2 gap-4">
                  {learningOutcomes.map((outcome, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <span>{outcome}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Curriculum */}
              <div data-aos="fade-up">
                <h2 className="text-2xl font-bold mb-6 flex items-center">
                  <BookOpen className="h-6 w-6 mr-2 text-primary" />
                  Course Curriculum
                </h2>
                <div className="space-y-4">
                  {curriculum.map((week, index) => (
                    <Card key={index} className="border-card-border">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center flex-shrink-0">
                            <span className="text-white font-semibold">{week.week}</span>
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg mb-3">{week.title}</h3>
                            <ul className="space-y-2">
                              {week.topics.map((topic, topicIndex) => (
                                <li key={topicIndex} className="flex items-center space-x-2">
                                  <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                                  <span className="text-muted-foreground">{topic}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Prerequisites */}
              <div data-aos="fade-up">
                <h2 className="text-2xl font-bold mb-6 flex items-center">
                  <Lightbulb className="h-6 w-6 mr-2 text-primary" />
                  Prerequisites
                </h2>
                <div className="space-y-3">
                  {prerequisites.map((prerequisite, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <span>{prerequisite}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Course Info Card */}
              <Card className="sticky top-24 border-card-border" data-aos="fade-up">
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-4">Course Information</h3>
                  <div className="space-y-4">
                    <div>
                      <span className="text-sm font-medium text-muted-foreground">Start Date:</span>
                      <p className="font-semibold">{course.startDate}</p>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-muted-foreground">End Date:</span>
                      <p className="font-semibold">{course.endDate}</p>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-muted-foreground">Schedule:</span>
                      <p className="font-semibold">{course.schedule}</p>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-muted-foreground">Language:</span>
                      <p className="font-semibold">{course.language}</p>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-muted-foreground">Certificate:</span>
                      <p className="font-semibold">{course.certificate}</p>
                    </div>
                  </div>

                  <div className="pt-6 border-t mt-6">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-2xl font-bold text-primary">${course.price}</span>
                      {course.originalPrice && (
                        <span className="text-sm text-muted-foreground line-through">
                          ${course.originalPrice}
                        </span>
                      )}
                    </div>
                    <Button 
                      className="w-full bg-gradient-primary text-white hover:opacity-90 mb-3"
                      onClick={handleEnrollClick}
                    >
                      Enroll Now
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Download className="mr-2 h-4 w-4" />
                      Download Brochure
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Instructor Card */}
              <Card className="border-card-border" data-aos="fade-up" data-aos-delay="100">
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-4">Meet Your Instructor</h3>
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center">
                      <span className="text-white font-semibold text-lg">
                        {course.instructor.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div>
                      <h4 className="font-semibold">{course.instructor.name}</h4>
                      <p className="text-sm text-muted-foreground">{course.instructor.title}</p>
                      <div className="flex items-center space-x-1 mt-1">
                        <Star className="h-4 w-4 text-yellow-400 fill-current" />
                        <span className="text-sm">{course.instructor.rating}</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    {course.instructor.bio}
                  </p>
                  <div className="text-sm">
                    <span className="font-medium">Experience:</span> {course.instructor.experience}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CourseDetails;