import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import CourseCard from '@/components/ui/course-card';
import { 
  Search,
  Filter,
  ArrowRight,
  BookOpen,
  Clock,
  Users,
  Star
} from 'lucide-react';

// Import images
import heroImage from '@/assets/hero-medical.jpg';
import educationBg from '@/assets/education-bg.jpg';

const Courses = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedLevel, setSelectedLevel] = useState('All');

  const categories = ['All', 'Surgery', 'Emergency', 'Pediatrics', 'Cardiology', 'Neurology', 'Internal Medicine'];
  const levels = ['All', 'Beginner', 'Intermediate', 'Advanced'];

  const allCourses = [
    {
      id: "advanced-surgery",
      title: "Advanced Surgical Techniques",
      description: "Master cutting-edge surgical procedures with hands-on training from world-renowned surgeons.",
      image: educationBg,
      duration: "12 weeks",
      students: 245,
      rating: 4.9,
      level: "Advanced" as const,
      price: 2499,
      originalPrice: 3499,
      instructor: "Dr. Michael Chen",
      category: "Surgery",
      startDate: "Feb 15",
      featured: true
    },
    {
      id: "emergency-medicine",
      title: "Emergency Medicine Essentials",
      description: "Critical care and emergency response training for healthcare professionals.",
      image: educationBg,
      duration: "8 weeks",
      students: 189,
      rating: 4.8,
      level: "Intermediate" as const,
      price: 1899,
      instructor: "Dr. Sarah Williams",
      category: "Emergency",
      startDate: "Mar 1",
    },
    {
      id: "pediatric-care",
      title: "Pediatric Care Fundamentals",
      description: "Comprehensive training in pediatric medicine and child healthcare.",
      image: educationBg,
      duration: "10 weeks",
      students: 156,
      rating: 4.9,
      level: "Beginner" as const,
      price: 1699,
      instructor: "Dr. Lisa Park",
      category: "Pediatrics",
      startDate: "Feb 20",
    },
    {
      id: "cardiac-intervention",
      title: "Cardiac Interventional Procedures",
      description: "Advanced training in cardiac catheterization and interventional cardiology.",
      image: educationBg,
      duration: "14 weeks",
      students: 98,
      rating: 4.9,
      level: "Advanced" as const,
      price: 2799,
      originalPrice: 3299,
      instructor: "Dr. Robert Kim",
      category: "Cardiology",
      startDate: "Mar 15",
      featured: true
    },
    {
      id: "neurology-basics",
      title: "Neurological Assessment & Diagnosis",
      description: "Fundamentals of neurological examination and diagnostic techniques.",
      image: educationBg,
      duration: "6 weeks",
      students: 134,
      rating: 4.7,
      level: "Intermediate" as const,
      price: 1399,
      instructor: "Dr. Amanda Foster",
      category: "Neurology",
      startDate: "Feb 28",
    },
    {
      id: "internal-medicine",
      title: "Internal Medicine Comprehensive",
      description: "Complete training program covering all aspects of internal medicine practice.",
      image: educationBg,
      duration: "16 weeks",
      students: 267,
      rating: 4.8,
      level: "Intermediate" as const,
      price: 2199,
      instructor: "Dr. James Thompson",
      category: "Internal Medicine",
      startDate: "Mar 10",
    },
    {
      id: "surgical-robotics",
      title: "Robotic Surgery Training",
      description: "Learn the latest in robotic surgical systems and minimally invasive techniques.",
      image: educationBg,
      duration: "8 weeks",
      students: 67,
      rating: 5.0,
      level: "Advanced" as const,
      price: 3199,
      originalPrice: 3999,
      instructor: "Dr. Elena Rodriguez",
      category: "Surgery",
      startDate: "Apr 1",
    },
    {
      id: "emergency-trauma",
      title: "Trauma Care & Emergency Surgery",
      description: "Critical skills for trauma assessment and emergency surgical interventions.",
      image: educationBg,
      duration: "10 weeks",
      students: 145,
      rating: 4.8,
      level: "Advanced" as const,
      price: 2299,
      instructor: "Dr. Mark Johnson",
      category: "Emergency",
      startDate: "Mar 20",
    },
    {
      id: "pediatric-emergency",
      title: "Pediatric Emergency Medicine",
      description: "Specialized training in pediatric emergency care and critical interventions.",
      image: educationBg,
      duration: "8 weeks",
      students: 89,
      rating: 4.9,
      level: "Intermediate" as const,
      price: 1999,
      instructor: "Dr. Jennifer Lee",
      category: "Pediatrics",
      startDate: "Mar 25",
    }
  ];

  const filteredCourses = allCourses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         course.instructor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || course.category === selectedCategory;
    const matchesLevel = selectedLevel === 'All' || course.level === selectedLevel;
    
    return matchesSearch && matchesCategory && matchesLevel;
  });

  const stats = [
    { number: "200+", label: "Active Courses", icon: BookOpen },
    { number: "15,000+", label: "Students Enrolled", icon: Users },
    { number: "500+", label: "Hours of Content", icon: Clock },
    { number: "4.9", label: "Average Rating", icon: Star }
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center justify-center">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-overlay" />
        
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <div data-aos="fade-up" data-aos-delay="100">
            <Badge className="mb-6 bg-white/20 text-white border-white/30 text-lg px-6 py-2">
              Medical Training Courses
            </Badge>
          </div>
          
          <h1 
            className="text-hero font-bold mb-6 leading-tight max-w-4xl mx-auto"
            data-aos="fade-up"
            data-aos-delay="200"
          >
            Master Medicine with
            <span className="block text-gradient bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
              Expert-Led Courses
            </span>
          </h1>
          
          <p 
            className="text-xl text-white/90 mb-8 max-w-3xl mx-auto leading-relaxed"
            data-aos="fade-up"
            data-aos-delay="300"
          >
            Advance your medical expertise with our comprehensive course catalog featuring 
            cutting-edge curriculum, hands-on training, and world-class instructors.
          </p>

          {/* Search Bar */}
          <div 
            className="max-w-lg mx-auto"
            data-aos="fade-up"
            data-aos-delay="400"
          >
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input 
                type="text"
                placeholder="Search courses, instructors, or topics..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-3 bg-white/90 backdrop-blur-sm border-white/20 text-gray-900 placeholder-gray-500 text-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div 
                key={stat.label}
                className="text-center"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <stat.icon className="h-8 w-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-primary mb-2">{stat.number}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="py-8 bg-gradient-soft border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5 text-muted-foreground" />
              <span className="font-semibold">Filter Courses:</span>
            </div>
            
            <div className="flex flex-wrap gap-4">
              {/* Category Filter */}
              <div className="flex flex-wrap gap-2">
                <span className="text-sm font-medium text-muted-foreground">Category:</span>
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category)}
                    className={selectedCategory === category ? "bg-primary text-white" : ""}
                  >
                    {category}
                  </Button>
                ))}
              </div>
              
              {/* Level Filter */}
              <div className="flex flex-wrap gap-2">
                <span className="text-sm font-medium text-muted-foreground">Level:</span>
                {levels.map((level) => (
                  <Button
                    key={level}
                    variant={selectedLevel === level ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedLevel(level)}
                    className={selectedLevel === level ? "bg-primary text-white" : ""}
                  >
                    {level}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="section-padding bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-2xl font-bold">
                {filteredCourses.length} Course{filteredCourses.length !== 1 ? 's' : ''} Found
              </h2>
              <p className="text-muted-foreground">
                {searchTerm && `Results for "${searchTerm}"`}
                {selectedCategory !== 'All' && ` in ${selectedCategory}`}
                {selectedLevel !== 'All' && ` • ${selectedLevel} level`}
              </p>
            </div>
          </div>

          {filteredCourses.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredCourses.map((course, index) => (
                <div 
                  key={course.id}
                  data-aos="fade-up"
                  data-aos-delay={index * 100}
                >
                  <CourseCard {...course} />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="h-12 w-12 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">No courses found</h3>
              <p className="text-muted-foreground mb-6">
                Try adjusting your search criteria or browse our featured courses.
              </p>
              <Button 
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory('All');
                  setSelectedLevel('All');
                }}
                className="bg-gradient-primary text-white hover:opacity-90"
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Featured Specialties */}
      <section className="section-padding bg-gradient-soft">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16" data-aos="fade-up">
            <Badge className="mb-6 bg-primary/10 text-primary">Course Categories</Badge>
            <h2 className="text-xl-heading mb-6">
              Explore Medical
              <span className="text-primary"> Specialties</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Discover courses across various medical specialties, each designed by expert practitioners 
              to advance your knowledge and skills.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.filter(cat => cat !== 'All').map((category, index) => {
              const categoryCount = allCourses.filter(course => course.category === category).length;
              return (
                <div 
                  key={category}
                  className="group cursor-pointer"
                  data-aos="fade-up"
                  data-aos-delay={index * 100}
                  onClick={() => setSelectedCategory(category)}
                >
                  <div className="bg-white rounded-xl p-6 shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1 border border-card-border">
                    <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                      <BookOpen className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                      {category}
                    </h3>
                    <p className="text-muted-foreground text-sm mb-4">
                      {categoryCount} course{categoryCount !== 1 ? 's' : ''} available
                    </p>
                    <div className="flex items-center text-primary text-sm font-semibold">
                      Explore Courses
                      <ArrowRight className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-overlay" />
        
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <div data-aos="fade-up">
            <h2 className="text-xl-heading mb-6">
              Ready to Advance Your
              <span className="block">Medical Expertise?</span>
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Join thousands of healthcare professionals who have advanced their careers 
              through our comprehensive course offerings.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold text-lg px-8">
                Browse All Courses
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-primary font-semibold text-lg px-8"
              >
                Contact Advisor
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Courses;